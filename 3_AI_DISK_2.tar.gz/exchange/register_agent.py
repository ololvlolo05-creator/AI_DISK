#!/usr/bin/env python3
"""Агент ИИ-обменника (GitHub Gist как общий хаб).

Что делает:
  1. Читает из хаба синхронизационный файл (список агентов + их tunnel-адреса).
  2. Регистрирует СЕБЯ: генерирует свой X25519-ключ, шифрует им свой адрес и
     данные (режим "записать новый файл в обменник") — AES-GCM по ключу хаба.
  3. Пишет обновлённый реестр обратно в хаб.

Секрет обмена (ключ хаба) хранится в /workspace/.vault_key (не покидает контейнер).
Для запуска нужен GitHub token с правом gist (репозиторий/секрет у пользователя).
"""
import os, sys, json, base64, argparse, urllib.request, urllib.error
from datetime import datetime, timezone
from cryptography.hazmat.primitives.asymmetric.x25519 import X25519PrivateKey
from cryptography.hazmat.primitives import serialization, hashes
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.kdf.hkdf import HKDF

VAULT = "/workspace/.vault_key"          # приватный ключ сервера (не выходит наружу)
PUB   = "/workspace/pubkey.txt"          # публичный ключ для чужих шифровок
STATE = "/workspace/exchange/hub_state.json"

def load_vault():
    from cryptography.hazmat.primitives.serialization import load_pem_private_key
    with open(VAULT, "rb") as f:
        k = load_pem_private_key(f.read(), password=None)
    if isinstance(k, X25519PrivateKey):
        return k
    # если ключ в другом формате — выводим сырые 32 байта и восстанавливаем X25519
    raw = k.private_bytes(serialization.Encoding.Raw,
                          serialization.PrivateFormat.Raw,
                          serialization.NoEncryption())
    return X25519PrivateKey.from_private_bytes(raw)

def hub_secret(priv):
    """Ключ хаба = HKDF( shared secret между двумя нашими ключами ).
    Пока это ОДИН контейнер — детерминированно из приватного ключа."""
    seed = priv.private_bytes(serialization.Encoding.DER,
                              serialization.PrivateFormat.PKCS8,
                              serialization.NoEncryption())
    return HKDF(algorithm=hashes.SHA256(), length=32, salt=b"ai-hub-v1",
                info=b"registry-key").derive(seed)

def enc_blob(key: bytes, data: bytes) -> dict:
    n = os.urandom(12)
    ct = AESGCM(key).encrypt(n, data, None)
    return {"n": base64.b64encode(n).decode(), "ct": base64.b64encode(ct).decode()}

def dec_blob(key: bytes, blob: dict) -> bytes:
    return AESGCM(key).decrypt(base64.b64decode(blob["n"]),
                               base64.b64decode(blob["ct"]), None)

# ---------- хаб: GitHub Gist ----------
def gist_req(url, tok, payload=None, method=None):
    req = urllib.request.Request(url, headers={"Authorization": f"Bearer {tok}",
                                               "Accept": "application/vnd.github+json"})
    if payload is not None:
        req.data = json.dumps(payload).encode()
        req.method = method or "POST"
    return json.load(urllib.request.urlopen(req))

def hub_read(tok, gist_id):
    g = gist_req(f"https://api.github.com/gists/{gist_id}", tok)
    fn = list(g["files"].values())[0]
    return json.loads(fn["content"])

def hub_write(tok, gist_id, state):
    body = json.dumps(state, ensure_ascii=False, indent=1)
    gist_req(f"https://api.github.com/gists/{gist_id}", tok,
             {"files": {"hub.json": {"content": body}}}, method="PATCH")

def cmd_register(tunnel_url, tok, gist_id, name):
    priv = load_vault()
    key = hub_secret(priv)
    pubb64 = open(PUB).read().strip()
    me = {"name": name or os.uname().nodename,
          "tunnel": tunnel_url,
          "pub": pubb64,
          "ts": datetime.now(timezone.utc).isoformat(),
          "mode": "sftp+mailbox"}
    sealed = enc_blob(key, json.dumps(me).encode())
    state = hub_read(tok, gist_id) if gist_id else {"agents": []}
    state["agents"] = [a for a in state.get("agents", [])
                       if dec_blob(key, a) .get("pub") != pubb64] + [sealed]
    hub_write(tok, gist_id, state)
    print(json.dumps({"ok": True, "agents": len(state["agents"])}))

def cmd_list(tok, gist_id):
    priv = load_vault(); key = hub_secret(priv)
    st = hub_read(tok, gist_id)
    out = [json.loads(dec_blob(key, a)) for a in st.get("agents", [])]
    print(json.dumps(out, ensure_ascii=False, indent=1))

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest="cmd", required=True)
    r = sub.add_parser("register"); r.add_argument("--tunnel", required=True)
    r.add_argument("--token", default=os.environ.get("GH_TOKEN","")); r.add_argument("--gist", default="")
    r.add_argument("--name", default="")
    l = sub.add_parser("list"); l.add_argument("--token", default=os.environ.get("GH_TOKEN",""))
    l.add_argument("--gist", required=True)
    a = ap.parse_args()
    if a.cmd == "register": cmd_register(a.tunnel, a.token, a.gist, a.name)
    else: cmd_list(a.token, a.gist)
